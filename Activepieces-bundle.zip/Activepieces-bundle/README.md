# Bermuda Saver — Activepieces handoff

This bundle contains the current Bermuda Saver application source, the editable workflow canvas, workflow specifications, privacy requirements and a ready-to-paste Activepieces prompt.

## Start here

1. Upload this ZIP as project context if your Activepieces workspace supports file/context upload.
2. Paste `ACTIVEPIECES-PROMPT.md` into the Activepieces assistant.
3. Ask it to create the workflows in a development workspace first.
4. Connect credentials only after inspecting every requested permission.
5. Test with synthetic receipts and prices. Do not use real shopper data until the privacy controls and retention rules are approved.

## Important

- `workflow-editor.html` and `workflow-specifications.md` are design references, not native Activepieces import files.
- `site-source/` is the current Bermuda Saver prototype source.
- Example retailer offers and historical index figures are illustrative unless explicitly source-labelled.
- Raw receipt images and identifiable shopping histories must never be sent to retailer analytics.

## Recommended build order

1. Identity and PIPA consent
2. Shelf-price submission
3. Receipt intake, duplicate detection and OCR
4. Verification and rewards
5. Retailer catalogue collection
6. Price Watch and Price Index publication
7. Saver Agent alerts and questions
8. Retailer offers
9. De-identified commercial analytics

