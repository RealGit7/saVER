import { env } from "cloudflare:workers";
import { headers } from "next/headers";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  const h = await headers();
  const userId = h.get("oai-authenticated-user-id");
  const email = h.get("oai-authenticated-user-email");
  if (!userId || !email) return NextResponse.json({ error: "Sign in required" }, { status: 401 });
  const data = await request.formData();
  const photo = data.get("photo");
  const product = String(data.get("product") || "").trim();
  const store = String(data.get("store") || "").trim();
  const price = Number(data.get("price"));
  const latitude = data.get("latitude") ? Number(data.get("latitude")) : null;
  const longitude = data.get("longitude") ? Number(data.get("longitude")) : null;
  const what3words = String(data.get("what3words") || "").trim() || null;
  if (!(photo instanceof File) || photo.size === 0 || photo.size > 10_000_000 || !product || !store || !Number.isFinite(price) || price <= 0) return NextResponse.json({ error: "Invalid submission" }, { status: 400 });

  const now = new Date().toISOString();
  const imageKey = `price-tags/${now.slice(0, 10)}/${crypto.randomUUID()}`;
  await env.BUCKET.put(imageKey, await photo.arrayBuffer(), { httpMetadata: { contentType: photo.type || "application/octet-stream" } });
  await env.DB.prepare("INSERT INTO contributors (user_id,email,display_name,points,created_at) VALUES (?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET email=excluded.email")
    .bind(userId, email, email, 0, now).run();
  const contributor = await env.DB.prepare("SELECT id FROM contributors WHERE user_id = ?").bind(userId).first<{ id: number }>();
  await env.DB.prepare("INSERT INTO observations (contributor_id,product,price,store_name,latitude,longitude,what3words,image_key,status,observed_at,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)")
    .bind(contributor!.id, product, price, store, latitude, longitude, what3words, imageKey, "pending", now, now).run();
  return NextResponse.json({ status: "pending", pendingPoints: 20 }, { status: 201 });
}
